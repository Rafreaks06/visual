﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        MenuStrip1 = New MenuStrip()
        FileToolStripMenuItem = New ToolStripMenuItem()
        SampleAlgorithmToolStripMenuItem = New ToolStripMenuItem()
        ManageToolStripMenuItem = New ToolStripMenuItem()
        ItemToolStripMenuItem = New ToolStripMenuItem()
        PositionToolStripMenuItem = New ToolStripMenuItem()
        RecapitulationToolStripMenuItem = New ToolStripMenuItem()
        EntityToolStripMenuItem = New ToolStripMenuItem()
        VendorToolStripMenuItem = New ToolStripMenuItem()
        CustomerToolStripMenuItem = New ToolStripMenuItem()
        ReportToolStripMenuItem = New ToolStripMenuItem()
        Paneltitle = New Panel()
        Label1 = New Label()
        Panelcontent = New Panel()
        Lblqotd = New Label()
        MenuStrip1.SuspendLayout()
        Paneltitle.SuspendLayout()
        Panelcontent.SuspendLayout()
        SuspendLayout()
        ' 
        ' MenuStrip1
        ' 
        MenuStrip1.Items.AddRange(New ToolStripItem() {FileToolStripMenuItem, ManageToolStripMenuItem, EntityToolStripMenuItem, ReportToolStripMenuItem})
        MenuStrip1.Location = New Point(0, 0)
        MenuStrip1.Name = "MenuStrip1"
        MenuStrip1.Size = New Size(824, 24)
        MenuStrip1.TabIndex = 0
        MenuStrip1.Text = "MenuStrip1"
        ' 
        ' FileToolStripMenuItem
        ' 
        FileToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {SampleAlgorithmToolStripMenuItem})
        FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        FileToolStripMenuItem.Size = New Size(37, 20)
        FileToolStripMenuItem.Text = "File"
        ' 
        ' SampleAlgorithmToolStripMenuItem
        ' 
        SampleAlgorithmToolStripMenuItem.Name = "SampleAlgorithmToolStripMenuItem"
        SampleAlgorithmToolStripMenuItem.Size = New Size(170, 22)
        SampleAlgorithmToolStripMenuItem.Text = "Sample Algorithm"
        ' 
        ' ManageToolStripMenuItem
        ' 
        ManageToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {ItemToolStripMenuItem, PositionToolStripMenuItem, RecapitulationToolStripMenuItem})
        ManageToolStripMenuItem.Name = "ManageToolStripMenuItem"
        ManageToolStripMenuItem.Size = New Size(62, 20)
        ManageToolStripMenuItem.Text = "Manage"
        ' 
        ' ItemToolStripMenuItem
        ' 
        ItemToolStripMenuItem.Name = "ItemToolStripMenuItem"
        ItemToolStripMenuItem.Size = New Size(150, 22)
        ItemToolStripMenuItem.Text = "Item "
        ' 
        ' PositionToolStripMenuItem
        ' 
        PositionToolStripMenuItem.Name = "PositionToolStripMenuItem"
        PositionToolStripMenuItem.Size = New Size(150, 22)
        PositionToolStripMenuItem.Text = "Position"
        ' 
        ' RecapitulationToolStripMenuItem
        ' 
        RecapitulationToolStripMenuItem.Name = "RecapitulationToolStripMenuItem"
        RecapitulationToolStripMenuItem.Size = New Size(150, 22)
        RecapitulationToolStripMenuItem.Text = "Recapitulation"
        ' 
        ' EntityToolStripMenuItem
        ' 
        EntityToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {VendorToolStripMenuItem, CustomerToolStripMenuItem})
        EntityToolStripMenuItem.Name = "EntityToolStripMenuItem"
        EntityToolStripMenuItem.Size = New Size(49, 20)
        EntityToolStripMenuItem.Text = "Entity"
        ' 
        ' VendorToolStripMenuItem
        ' 
        VendorToolStripMenuItem.Name = "VendorToolStripMenuItem"
        VendorToolStripMenuItem.Size = New Size(180, 22)
        VendorToolStripMenuItem.Text = "Vendor"
        ' 
        ' CustomerToolStripMenuItem
        ' 
        CustomerToolStripMenuItem.Name = "CustomerToolStripMenuItem"
        CustomerToolStripMenuItem.Size = New Size(180, 22)
        CustomerToolStripMenuItem.Text = "Customer"
        ' 
        ' ReportToolStripMenuItem
        ' 
        ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        ReportToolStripMenuItem.Size = New Size(54, 20)
        ReportToolStripMenuItem.Text = "Report"
        ' 
        ' Paneltitle
        ' 
        Paneltitle.Controls.Add(Label1)
        Paneltitle.Location = New Point(0, 27)
        Paneltitle.Name = "Paneltitle"
        Paneltitle.Size = New Size(800, 70)
        Paneltitle.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(338, 24)
        Label1.Name = "Label1"
        Label1.Size = New Size(111, 15)
        Label1.TabIndex = 2
        Label1.Text = "Item Managemenet"
        ' 
        ' Panelcontent
        ' 
        Panelcontent.Controls.Add(Lblqotd)
        Panelcontent.Location = New Point(0, 103)
        Panelcontent.Name = "Panelcontent"
        Panelcontent.Size = New Size(800, 427)
        Panelcontent.TabIndex = 2
        ' 
        ' Lblqotd
        ' 
        Lblqotd.AutoSize = True
        Lblqotd.Location = New Point(300, 12)
        Lblqotd.Name = "Lblqotd"
        Lblqotd.Size = New Size(58, 15)
        Lblqotd.TabIndex = 1
        Lblqotd.Text = "Kata-Kata"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(824, 527)
        Controls.Add(Panelcontent)
        Controls.Add(Paneltitle)
        Controls.Add(MenuStrip1)
        MainMenuStrip = MenuStrip1
        Name = "Form1"
        Text = "vb 1124160189"
        MenuStrip1.ResumeLayout(False)
        MenuStrip1.PerformLayout()
        Paneltitle.ResumeLayout(False)
        Paneltitle.PerformLayout()
        Panelcontent.ResumeLayout(False)
        Panelcontent.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SampleAlgorithmToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManageToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ItemToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PositionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RecapitulationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EntityToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VendorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CustomerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Paneltitle As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panelcontent As Panel
    Friend WithEvents Lblqotd As Label

End Class
