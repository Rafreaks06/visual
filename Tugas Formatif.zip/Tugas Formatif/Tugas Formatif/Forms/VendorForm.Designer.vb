﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VendorForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btndel = New Button()
        btnsubmit = New Button()
        Label5 = New Label()
        txtemail = New TextBox()
        Label3 = New Label()
        Label4 = New Label()
        txtphone = New TextBox()
        txtaddres = New TextBox()
        Label2 = New Label()
        label1 = New Label()
        txtname = New TextBox()
        txtcode = New TextBox()
        Label6 = New Label()
        txtperson = New TextBox()
        txtid = New TextBox()
        SuspendLayout()
        ' 
        ' btndel
        ' 
        btndel.BackColor = Color.Red
        btndel.ForeColor = SystemColors.ControlLightLight
        btndel.Location = New Point(212, 296)
        btndel.Name = "btndel"
        btndel.Size = New Size(59, 33)
        btndel.TabIndex = 31
        btndel.Text = "Delete"
        btndel.UseVisualStyleBackColor = False
        ' 
        ' btnsubmit
        ' 
        btnsubmit.BackColor = SystemColors.ActiveCaption
        btnsubmit.ForeColor = SystemColors.ControlLightLight
        btnsubmit.Location = New Point(129, 296)
        btnsubmit.Name = "btnsubmit"
        btnsubmit.Size = New Size(59, 33)
        btnsubmit.TabIndex = 30
        btnsubmit.Text = "Submit"
        btnsubmit.UseVisualStyleBackColor = False
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(11, 222)
        Label5.Name = "Label5"
        Label5.Size = New Size(36, 15)
        Label5.TabIndex = 29
        Label5.Text = "Email"
        ' 
        ' txtemail
        ' 
        txtemail.Location = New Point(110, 222)
        txtemail.Name = "txtemail"
        txtemail.Size = New Size(177, 23)
        txtemail.TabIndex = 28
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(11, 193)
        Label3.Name = "Label3"
        Label3.Size = New Size(41, 15)
        Label3.TabIndex = 27
        Label3.Text = "Phone"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(11, 102)
        Label4.Name = "Label4"
        Label4.Size = New Size(44, 15)
        Label4.TabIndex = 26
        Label4.Text = "Addres"
        ' 
        ' txtphone
        ' 
        txtphone.Location = New Point(110, 193)
        txtphone.Name = "txtphone"
        txtphone.Size = New Size(177, 23)
        txtphone.TabIndex = 25
        ' 
        ' txtaddres
        ' 
        txtaddres.Location = New Point(110, 99)
        txtaddres.Multiline = True
        txtaddres.Name = "txtaddres"
        txtaddres.Size = New Size(177, 88)
        txtaddres.TabIndex = 24
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(11, 58)
        Label2.Name = "Label2"
        Label2.Size = New Size(39, 15)
        Label2.TabIndex = 23
        Label2.Text = "Name"
        ' 
        ' label1
        ' 
        label1.AutoSize = True
        label1.Location = New Point(11, 19)
        label1.Name = "label1"
        label1.Size = New Size(35, 15)
        label1.TabIndex = 22
        label1.Text = "Code"
        ' 
        ' txtname
        ' 
        txtname.Location = New Point(110, 58)
        txtname.Name = "txtname"
        txtname.Size = New Size(177, 23)
        txtname.TabIndex = 21
        ' 
        ' txtcode
        ' 
        txtcode.Location = New Point(110, 16)
        txtcode.Name = "txtcode"
        txtcode.Size = New Size(177, 23)
        txtcode.TabIndex = 20
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(12, 259)
        Label6.Name = "Label6"
        Label6.Size = New Size(97, 15)
        Label6.TabIndex = 33
        Label6.Text = "Person in Charge"
        ' 
        ' txtperson
        ' 
        txtperson.Location = New Point(110, 251)
        txtperson.Name = "txtperson"
        txtperson.Size = New Size(177, 23)
        txtperson.TabIndex = 32
        ' 
        ' txtid
        ' 
        txtid.Location = New Point(110, 335)
        txtid.Name = "txtid"
        txtid.Size = New Size(94, 23)
        txtid.TabIndex = 34
        txtid.Visible = False
        ' 
        ' VendorForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(442, 412)
        Controls.Add(txtid)
        Controls.Add(Label6)
        Controls.Add(txtperson)
        Controls.Add(btndel)
        Controls.Add(btnsubmit)
        Controls.Add(Label5)
        Controls.Add(txtemail)
        Controls.Add(Label3)
        Controls.Add(Label4)
        Controls.Add(txtphone)
        Controls.Add(txtaddres)
        Controls.Add(Label2)
        Controls.Add(label1)
        Controls.Add(txtname)
        Controls.Add(txtcode)
        Name = "VendorForm"
        Text = "Vendor"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btndel As Button
    Friend WithEvents btnsubmit As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents txtemail As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtphone As TextBox
    Friend WithEvents txtaddres As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents label1 As Label
    Friend WithEvents txtname As TextBox
    Friend WithEvents txtcode As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtperson As TextBox
    Friend WithEvents txtid As TextBox
End Class
