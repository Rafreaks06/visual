﻿Imports Npgsql


Public Class itemform1
    Private Sub itemform1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadpos()
        loadVendor()
    End Sub
    Public Sub loadpos()
        Dim posdao As New PosDao
        Dim rs As NpgsqlDataReader = posdao.getAllcode()
        While rs.Read()
            Combopst.Items.Add(rs.GetString(0))
        End While
        posdao.clearConnection(rs)
        Combopst.SelectedText = "Choose"
    End Sub
    Public Sub loadVendor()
        Dim vendordao As New VendorDao
        Dim rs As NpgsqlDataReader = VendorDao.getAllCode()
        While rs.Read()
            Combovendor.Items.Add(rs.GetString(0))
        End While
        vendordao.clearConnection(rs)
        Combovendor.SelectedText = "Choose"
    End Sub

    Public Sub populatepos()
        Dim poscode As String = Combopst.SelectedItem.ToString
        Dim posdao As New PosDao()
        Dim rs As NpgsqlDataReader = posdao.getObjectByCode(poscode)
        While rs.Read()
            txtdetailPost.Text = rs.GetString(0) & Environment.NewLine & rs.GetString(1) & Environment.NewLine
            txtdetailPost.Text = txtdetailPost.Text & "Max: " & rs.GetDouble(2) & Environment.NewLine
            txtdetailPost.Text = txtdetailPost.Text & "Filled: " & rs.GetDouble(3)
            Exit While
        End While
        posdao.clearConnection(rs)
    End Sub
    Public Sub populateVendor()
        Dim vendorcode As String = Combovendor.SelectedItem.ToString
        Dim vendordao As New VendorDao()
        Dim rs As NpgsqlDataReader = vendordao.getObjectByCode(vendorcode)
        While rs.Read()
            txtdetailVendor.Text = "Name: " & rs.GetString(0) & Environment.NewLine
            txtdetailVendor.Text = txtdetailVendor.Text & "Addres: " & rs.GetString(1) & Environment.NewLine
            txtdetailVendor.Text = txtdetailVendor.Text & Environment.NewLine
            txtdetailVendor.Text = txtdetailVendor.Text & "Phone: " & rs.GetString(2) & Environment.NewLine
            txtdetailVendor.Text = txtdetailVendor.Text & Environment.NewLine
            txtdetailVendor.Text = txtdetailVendor.Text & "Email: " & rs.GetString(3) & Environment.NewLine
            txtdetailVendor.Text = txtdetailVendor.Text & Environment.NewLine
            txtdetailVendor.Text = txtdetailVendor.Text & "Pic: " & rs.GetString(4)
            Exit While
        End While
        vendordao.clearConnection(rs)
    End Sub
    Private Sub Combopst_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combopst.SelectedIndexChanged
        populatepos()
    End Sub

    Private Sub Combovendor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combovendor.SelectedIndexChanged
        populateVendor()
    End Sub

    Private Sub btnsubmit_Click(sender As Object, e As EventArgs) Handles btnsubmit.Click
        Dim code As String = txtcode.Text
        Dim measurement As String = Combomst.SelectedItem.ToString
        Dim poscode As String = Combopst.SelectedItem.ToString
        Dim vendorcode As String = Combovendor.SelectedItem.ToString
        Dim price As Integer = CInt(txtprice.Text)
        Dim stock As Integer = CInt(txtstock.Text)

        If poscode = "Choose" Or vendorcode = "Choose" Then
            MessageBox.Show("Invalid Data")
        Else
            Dim itemdao As New itemdao()
            Dim posdao As New PosDao()
            Dim vendordao As New VendorDao()
            Dim posid As Integer = posdao.getidbycode(poscode)
            Dim vendorid As Integer = vendordao.getIdByCode(vendorcode)


            If txtid.Text Is "" Then
                itemdao.insert(code, txtname.Text, measurement)
                Dim itemid As Integer = itemdao.getIdByCode(code)
                itemdao.insertDetail(itemid, posid, vendorid, price, stock)
            Else
                Dim id As Integer = CInt(txtid.Text)
                itemdao.update(code, txtname.Text, measurement, id)
                Dim detailid As Integer = itemdao.getIdDetailByCodes(code, vendorcode)
                itemdao.updateDetail(posid, vendorid, price, stock, id, detailid)
            End If
        End If

    End Sub
End Class