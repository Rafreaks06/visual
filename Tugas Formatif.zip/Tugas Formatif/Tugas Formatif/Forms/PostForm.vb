﻿Public Class PostForm
    Private Sub PostForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If String.IsNullOrEmpty(txtId.Text) Then
            btnDelete.Hide()
        Else
            btnDelete.Show()
        End If
    End Sub
    Private Sub btnsubmit_Click(sender As Object, e As EventArgs) Handles btnsubmit.Click
        Try
            Dim Posdao As New PosDao

            Dim code As String = txtcode.Text
            Dim name As String = txtname.Text
            Dim Description As String = txtdesc.Text
            Dim Capacity As Double = txtmax.Text
            Dim Filled As Double = txtfield.Text
            'edit-daffa'


            If txtId.Text Is "" Then
                Posdao.insert(code, name, Description, Capacity, Filled)
            Else
                Dim id As Integer = CInt(txtId.Text)
                Posdao.update(code, name, Description, Capacity, Filled, id)
            End If

            MessageBox.Show("Data Berhasil Ditambahkan")
        Catch x As Exception
            MessageBox.Show("Failed to insert:" & x.Message)
        End Try

    End Sub

    'ini dibuat daffa
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim posdao As New PosDao
        Try
            If String.IsNullOrEmpty(txtId.Text) Then 'kondisi jika id kosong' 
                MessageBox.Show("Data is not exist")
            Else
                Dim id As String = txtId.Text
                PosDao.delete(CInt(id))
                MessageBox.Show("Data has been delete succesfully")
                Hide()
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class