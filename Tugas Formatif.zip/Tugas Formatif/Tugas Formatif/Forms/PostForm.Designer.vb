﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PostForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label2 = New Label()
        label1 = New Label()
        txtname = New TextBox()
        txtcode = New TextBox()
        Label3 = New Label()
        Label4 = New Label()
        txtmax = New TextBox()
        txtdesc = New TextBox()
        Label5 = New Label()
        txtfield = New TextBox()
        btnDelete = New Button()
        btnsubmit = New Button()
        txtId = New TextBox()
        SuspendLayout()
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(14, 64)
        Label2.Name = "Label2"
        Label2.Size = New Size(39, 15)
        Label2.TabIndex = 8
        Label2.Text = "Name"
        ' 
        ' label1
        ' 
        label1.AutoSize = True
        label1.Location = New Point(14, 25)
        label1.Name = "label1"
        label1.Size = New Size(35, 15)
        label1.TabIndex = 7
        label1.Text = "Code"
        ' 
        ' txtname
        ' 
        txtname.Location = New Point(113, 64)
        txtname.Name = "txtname"
        txtname.Size = New Size(139, 23)
        txtname.TabIndex = 6
        ' 
        ' txtcode
        ' 
        txtcode.Location = New Point(113, 22)
        txtcode.Name = "txtcode"
        txtcode.Size = New Size(139, 23)
        txtcode.TabIndex = 5
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(14, 199)
        Label3.Name = "Label3"
        Label3.Size = New Size(79, 15)
        Label3.TabIndex = 12
        Label3.Text = "Max Capacity"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(14, 108)
        Label4.Name = "Label4"
        Label4.Size = New Size(67, 15)
        Label4.TabIndex = 11
        Label4.Text = "Description"
        ' 
        ' txtmax
        ' 
        txtmax.Location = New Point(113, 199)
        txtmax.Name = "txtmax"
        txtmax.Size = New Size(139, 23)
        txtmax.TabIndex = 10
        ' 
        ' txtdesc
        ' 
        txtdesc.Location = New Point(113, 105)
        txtdesc.Multiline = True
        txtdesc.Name = "txtdesc"
        txtdesc.Size = New Size(139, 88)
        txtdesc.TabIndex = 9
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(14, 245)
        Label5.Name = "Label5"
        Label5.Size = New Size(32, 15)
        Label5.TabIndex = 14
        Label5.Text = "Field"
        ' 
        ' txtfield
        ' 
        txtfield.Location = New Point(113, 245)
        txtfield.Name = "txtfield"
        txtfield.Size = New Size(139, 23)
        txtfield.TabIndex = 13
        ' 
        ' btnDelete
        ' 
        btnDelete.BackColor = Color.IndianRed
        btnDelete.ForeColor = Color.WhiteSmoke
        btnDelete.Location = New Point(113, 302)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(59, 33)
        btnDelete.TabIndex = 19
        btnDelete.Text = "Delete"
        btnDelete.UseVisualStyleBackColor = False
        ' 
        ' btnsubmit
        ' 
        btnsubmit.BackColor = SystemColors.ControlLight
        btnsubmit.Location = New Point(193, 302)
        btnsubmit.Name = "btnsubmit"
        btnsubmit.Size = New Size(59, 33)
        btnsubmit.TabIndex = 18
        btnsubmit.Text = "Submit"
        btnsubmit.UseVisualStyleBackColor = False
        ' 
        ' txtId
        ' 
        txtId.Location = New Point(0, 348)
        txtId.Name = "txtId"
        txtId.Size = New Size(139, 23)
        txtId.TabIndex = 20
        txtId.Visible = False
        ' 
        ' PostForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(373, 383)
        Controls.Add(txtId)
        Controls.Add(btnDelete)
        Controls.Add(btnsubmit)
        Controls.Add(Label5)
        Controls.Add(txtfield)
        Controls.Add(Label3)
        Controls.Add(Label4)
        Controls.Add(txtmax)
        Controls.Add(txtdesc)
        Controls.Add(Label2)
        Controls.Add(label1)
        Controls.Add(txtname)
        Controls.Add(txtcode)
        Name = "PostForm"
        Text = "Position"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents label1 As Label
    Friend WithEvents txtname As TextBox
    Friend WithEvents txtcode As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtmax As TextBox
    Friend WithEvents txtdesc As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtfield As TextBox
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnsubmit As Button
    Friend WithEvents txtId As TextBox
End Class
