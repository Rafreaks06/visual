﻿Imports System.Data.Common
Imports Npgsql

Public Class PosDao
    Dim npgsqlConn As NpgsqlConnection
    Dim cmd As NpgsqlCommand
    Dim rs As NpgsqlDataReader
    Dim adp As NpgsqlDataAdapter
    Dim query As String
    Dim result As Integer

    Public Function loadAlldata() As DataTable
        query = "select * from Positions p where p.isdelete is null" 'query database'
        npgsqlConn = Dbconnnection.openconnection 'pembukaan koneksi'
        cmd = New NpgsqlCommand(query, npgsqlConn) 'eksekusi query berdasarkan koneksi'
        adp = New NpgsqlDataAdapter(cmd) 'mengambil data hasil query'
        Dim table As New DataTable() 'definisi tabel penampungan'
        adp.Fill(table) 'data ditampung di table'

        Return table

    End Function
    Public Function insert(code As String, name As String, Description As String, max_capacity As Double, Filled As Double) As Integer 'memberikan value'
        npgsqlConn = Dbconnnection.openconnection()
        query = "insert into positions (code, name, description, max_capacity, filled)"
        query = query & " Values (@code, @name, @description, @max_capacity, @filled)" 'query insert'
        cmd = New NpgsqlCommand(query, npgsqlConn)
        cmd.Parameters.AddWithValue("@code", code)
        cmd.Parameters.AddWithValue("@name", name)
        cmd.Parameters.AddWithValue("@description", Description)
        cmd.Parameters.AddWithValue("@max_capacity", CDbl(max_capacity))
        cmd.Parameters.AddWithValue("@filled", CDbl(Filled))
        Dim result As Integer
        result = cmd.ExecuteNonQuery()
        Dbconnnection.CloseConnection()
        Return result
    End Function

    Public Function update(code As String, name As String, description As String, max As Double, filled As Double, id As Integer) As Integer
        npgsqlConn = Dbconnnection.openconnection()
        query = "update positions set code = @code, name = @name, description = @description, max_capacity = @max_capacity, filled = @filled, updated_on = @updated_on where id = @id "
        cmd = New NpgsqlCommand(query, npgsqlConn)
        cmd.Parameters.AddWithValue("@code", code)
        cmd.Parameters.AddWithValue("@name", name)
        cmd.Parameters.AddWithValue("@description", description)
        cmd.Parameters.AddWithValue("@max_capacity", max)
        cmd.Parameters.AddWithValue("@filled", filled)
        cmd.Parameters.AddWithValue("@updated_on", DateTime.Now)
        cmd.Parameters.AddWithValue("@id", id)
        Dim result As Integer
        result = cmd.ExecuteNonQuery()
        Dbconnnection.CloseConnection()
        Return result

    End Function

    Public Function delete(id As Integer) As Integer
        npgsqlConn = Dbconnnection.openconnection()
        query = "update positions set isdelete = @flagyes, updated_on = @updated_on where id = @id "
        cmd = New NpgsqlCommand(query, npgsqlConn)
        cmd.Parameters.AddWithValue("@flagyes", 1)
        cmd.Parameters.AddWithValue("@updated_on", DateTime.Now)
        cmd.Parameters.AddWithValue("@id", id)
        Dim result As Integer
        result = cmd.ExecuteNonQuery()
        Dbconnnection.CloseConnection()
        Return result
    End Function
    Public Sub clearConnection(activeRs As NpgsqlDataReader)
        If activeRs.IsClosed = False Then
            activeRs.Close()
        End If
        Dbconnnection.CloseConnection()
    End Sub
    Public Function getAllCode() As NpgsqlDataReader
        npgsqlConn = Dbconnnection.openconnection()
        query = "select code from positions where isdelete is null"
        cmd = New NpgsqlCommand(query, npgsqlConn)
        rs = cmd.ExecuteReader()
        Return rs
    End Function
    Public Function getIdByCode(code As String) As Integer
        npgsqlConn = Dbconnnection.openconnection()
        query = "SELECT v.id from positions v where v.code = @code"
        cmd = New NpgsqlCommand(query, npgsqlConn)
        cmd.Parameters.AddWithValue("@code", code)
        rs = cmd.ExecuteReader()
        While rs.Read()
            result = rs.GetInt32(0)
            Exit While
        End While
        Return result
    End Function

    Public Function getObjectByCode(code As String) As NpgsqlDataReader
        npgsqlConn = Dbconnnection.openconnection()
        query = "SELECT x.name, x.description, x.max_capacity, x.filled " &
            "from positions x where x.code = @code and isdelete is null"
        cmd = New NpgsqlCommand(query, npgsqlConn)
        cmd.Parameters.AddWithValue("@code", code)
        rs = cmd.ExecuteReader()
        Return rs
    End Function
End Class
