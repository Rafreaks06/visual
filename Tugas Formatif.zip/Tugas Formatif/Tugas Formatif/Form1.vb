﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Lblqotd.Text = "kalo bisa menyerah kenapa harus berusaha" & Environment.NewLine
        Lblqotd.Text = Lblqotd.Text & "Raffi Sigma"

    End Sub

    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.Click

    End Sub

    Private Sub SampleAlgorithmToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SampleAlgorithmToolStripMenuItem.Click
        loadmenu(New algorithmcontrol)
    End Sub
    Private Sub loadmenu(control As UserControl)
        Panelcontent.Controls.Clear()
        control.Dock = DockStyle.Fill
        Panelcontent.Controls.Add(control)
    End Sub



    Private Sub loaditem(control As UserControl)
        Panelcontent.Controls.Clear()
        control.Dock = DockStyle.Fill
        Panelcontent.Controls.Add(control)
    End Sub

    Private Sub EntityToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EntityToolStripMenuItem.Click

    End Sub

    Private Sub VendorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VendorToolStripMenuItem.Click
        loadmenu(New Vendor)
    End Sub

    Private Sub Lblqotd_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Panelcontent_Paint(sender As Object, e As PaintEventArgs) Handles Panelcontent.Paint

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PositionToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PositionToolStripMenuItem.Click
        loadmenu(New Positions)

    End Sub

    Private Sub ManageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManageToolStripMenuItem.Click

    End Sub

    Private Sub ItemToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ItemToolStripMenuItem.Click
        loadmenu(New item)
    End Sub
End Class
