﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Vendor
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        DataGridVendor = New DataGridView()
        btnaddVendor = New Button()
        LabelVendor = New Label()
        btnref = New Button()
        CType(DataGridVendor, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' DataGridVendor
        ' 
        DataGridVendor.AllowUserToAddRows = False
        DataGridVendor.AllowUserToDeleteRows = False
        DataGridVendor.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridVendor.Location = New Point(6, 108)
        DataGridVendor.Name = "DataGridVendor"
        DataGridVendor.ReadOnly = True
        DataGridVendor.Size = New Size(705, 289)
        DataGridVendor.TabIndex = 5
        ' 
        ' btnaddVendor
        ' 
        btnaddVendor.Location = New Point(558, 20)
        btnaddVendor.Name = "btnaddVendor"
        btnaddVendor.Size = New Size(153, 42)
        btnaddVendor.TabIndex = 4
        btnaddVendor.Text = "Add New"
        btnaddVendor.UseVisualStyleBackColor = True
        ' 
        ' LabelVendor
        ' 
        LabelVendor.AutoSize = True
        LabelVendor.Location = New Point(6, 47)
        LabelVendor.Margin = New Padding(6, 0, 6, 0)
        LabelVendor.Name = "LabelVendor"
        LabelVendor.Size = New Size(83, 15)
        LabelVendor.TabIndex = 3
        LabelVendor.Text = "Master Vendor"
        ' 
        ' btnref
        ' 
        btnref.Location = New Point(387, 20)
        btnref.Name = "btnref"
        btnref.Size = New Size(153, 42)
        btnref.TabIndex = 6
        btnref.Text = "Refresh"
        btnref.UseVisualStyleBackColor = True
        ' 
        ' Vendor
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        Controls.Add(btnref)
        Controls.Add(DataGridVendor)
        Controls.Add(btnaddVendor)
        Controls.Add(LabelVendor)
        Name = "Vendor"
        Size = New Size(716, 445)
        CType(DataGridVendor, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents DataGridVendor As DataGridView
    Friend WithEvents btnaddVendor As Button
    Friend WithEvents LabelVendor As Label
    Friend WithEvents btnref As Button

End Class
