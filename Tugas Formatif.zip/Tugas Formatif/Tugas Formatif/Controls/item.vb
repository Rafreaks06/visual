﻿Public Class item
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridpositions.CellContentClick

    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnnew.Click
        itemform1.Show()
    End Sub

    Private Sub item_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub labelmaster_Click(sender As Object, e As EventArgs) Handles labelmaster.Click

    End Sub
End Class
