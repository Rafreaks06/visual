﻿Public Class Positions
    Private Sub Positions_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadData()
    End Sub
    Public Sub loadData()
        Try
            Dim PosDao As New PosDao() 'mengambi database'
            Dim table As DataTable = PosDao.loadAlldata() 'memuat semua data'
            DataGridPositions.DataSource = table 'tempel ke design'
            DataGridPositions.Columns("id").Visible = False 'umpetin id'
        Catch ex As Exception
            MessageBox.Show("Gagal Mengambil data:" & ex.Message)
        End Try
    End Sub

    Private Sub btnaddPositions_Click(sender As Object, e As EventArgs) Handles btnaddPositions.Click
        PostForm.Show()

    End Sub

    Private Sub DataGridPositions_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridPositions.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DataGridPositions.Rows(e.RowIndex)
            Dim formPos As PostForm = New PostForm()
            formPos.txtcode.Text = row.Cells("code").Value.ToString()
            formPos.txtdesc.Text = row.Cells("description").Value.ToString()
            formPos.txtfield.Text = row.Cells("filled").Value.ToString()
            formPos.txtId.Text = row.Cells("id").Value.ToString()
            formPos.txtmax.Text = row.Cells("max_capacity").Value.ToString()
            formPos.txtname.Text = row.Cells("name").Value.ToString()
            formPos.Show()
        End If
    End Sub

    Private Sub btnref_Click(sender As Object, e As EventArgs) Handles btnref.Click
        loadData()
    End Sub
End Class


