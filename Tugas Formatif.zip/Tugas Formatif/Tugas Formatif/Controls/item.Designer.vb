﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class item
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        labelmaster = New Label()
        btnnew = New Button()
        DataGridpositions = New DataGridView()
        CType(DataGridpositions, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' labelmaster
        ' 
        labelmaster.AutoSize = True
        labelmaster.Location = New Point(42, 13)
        labelmaster.Margin = New Padding(6, 0, 6, 0)
        labelmaster.Name = "labelmaster"
        labelmaster.Size = New Size(131, 30)
        labelmaster.TabIndex = 0
        labelmaster.Text = "Master Item"
        ' 
        ' btnnew
        ' 
        btnnew.Location = New Point(510, 7)
        btnnew.Name = "btnnew"
        btnnew.Size = New Size(153, 42)
        btnnew.TabIndex = 1
        btnnew.Text = "Add New"
        btnnew.UseVisualStyleBackColor = True
        ' 
        ' DataGridpositions
        ' 
        DataGridpositions.AllowUserToAddRows = False
        DataGridpositions.AllowUserToDeleteRows = False
        DataGridpositions.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridpositions.Location = New Point(42, 74)
        DataGridpositions.Name = "DataGridpositions"
        DataGridpositions.ReadOnly = True
        DataGridpositions.Size = New Size(621, 289)
        DataGridpositions.TabIndex = 2
        ' 
        ' item
        ' 
        AutoScaleDimensions = New SizeF(13.0F, 30.0F)
        AutoScaleMode = AutoScaleMode.Font
        Controls.Add(DataGridpositions)
        Controls.Add(btnnew)
        Controls.Add(labelmaster)
        Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Margin = New Padding(6)
        Name = "item"
        Size = New Size(768, 482)
        CType(DataGridpositions, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents labelmaster As Label
    Friend WithEvents btnnew As Button
    Friend WithEvents DataGridpositions As DataGridView

End Class
