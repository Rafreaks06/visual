﻿Imports System.Linq.Expressions

Public Class VendorForm
    Private Sub txtfield_TextChanged(sender As Object, e As EventArgs) Handles txtemail.TextChanged

    End Sub

    Private Sub btnsubmit_Click(sender As Object, e As EventArgs) Handles btnsubmit.Click
        Try
            Dim VendorDao As New VendorDao
            Dim code As String = txtcode.Text
            Dim name As String = txtname.Text
            Dim addres As String = txtaddres.Text
            Dim phone As String = txtphone.Text
            Dim email As String = txtemail.Text
            Dim pic As String = txtperson.Text


            If String.IsNullOrEmpty(txtid.Text) Then 'kondisi jika id kosong' 
                VendorDao.insert(code, name, addres, phone, email, pic)
                MessageBox.Show("Data Berhasil Ditambahkan")
            Else
                Dim id As String = txtid.Text
                VendorDao.update(code, name, addres, phone, email, pic, CInt(id))
                MessageBox.Show("Data Berhasil Diupdate")

            End If

        Catch x As Exception
            MessageBox.Show("Failed to insert:" & x.Message)
        End Try

    End Sub

    Private Sub VendorForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If String.IsNullOrEmpty(txtid.Text) Then 'kondisi jika id kosong' 
            btndel.Hide()
        Else
            btndel.Show()
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtid.TextChanged

    End Sub

    Private Sub btndel_Click(sender As Object, e As EventArgs) Handles btndel.Click
        Dim VendorDao As New VendorDao
        If String.IsNullOrEmpty(txtid.Text) Then 'kondisi jika id kosong' 
            MessageBox.Show("Data is not exist")
        Else
            Dim id As String = txtid.Text
            VendorDao.delete(CInt(id))
            MessageBox.Show("Data has been delete succesfully")
            Hide()
        End If
    End Sub
End Class