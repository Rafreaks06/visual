﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class itemform1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtcode = New TextBox()
        txtname = New TextBox()
        label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Combopst = New ComboBox()
        Combovendor = New ComboBox()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Combomst = New ComboBox()
        txtstock = New TextBox()
        txtprice = New TextBox()
        Label7 = New Label()
        btnsubmit = New Button()
        btndel = New Button()
        txtdetailPost = New TextBox()
        txtdetailVendor = New TextBox()
        label20 = New Label()
        label30 = New Label()
        SuspendLayout()
        ' 
        ' txtcode
        ' 
        txtcode.Location = New Point(132, 19)
        txtcode.Name = "txtcode"
        txtcode.Size = New Size(121, 23)
        txtcode.TabIndex = 0
        ' 
        ' txtname
        ' 
        txtname.Location = New Point(132, 61)
        txtname.Name = "txtname"
        txtname.Size = New Size(121, 23)
        txtname.TabIndex = 2
        ' 
        ' label1
        ' 
        label1.AutoSize = True
        label1.Location = New Point(33, 22)
        label1.Name = "label1"
        label1.Size = New Size(33, 15)
        label1.TabIndex = 3
        label1.Text = "code"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(33, 61)
        Label2.Name = "Label2"
        Label2.Size = New Size(39, 15)
        Label2.TabIndex = 4
        Label2.Text = "Name"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(12, 116)
        Label3.Name = "Label3"
        Label3.Size = New Size(80, 15)
        Label3.TabIndex = 5
        Label3.Text = "Measurement"
        ' 
        ' Combopst
        ' 
        Combopst.FormattingEnabled = True
        Combopst.Location = New Point(132, 157)
        Combopst.Name = "Combopst"
        Combopst.Size = New Size(121, 23)
        Combopst.TabIndex = 6
        ' 
        ' Combovendor
        ' 
        Combovendor.FormattingEnabled = True
        Combovendor.Location = New Point(132, 206)
        Combovendor.Name = "Combovendor"
        Combovendor.Size = New Size(121, 23)
        Combovendor.TabIndex = 7
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(31, 165)
        Label4.Name = "Label4"
        Label4.Size = New Size(50, 15)
        Label4.TabIndex = 9
        Label4.Text = "Position"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(31, 214)
        Label5.Name = "Label5"
        Label5.Size = New Size(44, 15)
        Label5.TabIndex = 10
        Label5.Text = "Vendor"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(33, 259)
        Label6.Name = "Label6"
        Label6.Size = New Size(33, 15)
        Label6.TabIndex = 11
        Label6.Text = "Price"
        ' 
        ' Combomst
        ' 
        Combomst.FormattingEnabled = True
        Combomst.Items.AddRange(New Object() {"Pieces", "Grams", "Other"})
        Combomst.Location = New Point(132, 113)
        Combomst.Name = "Combomst"
        Combomst.Size = New Size(121, 23)
        Combomst.TabIndex = 12
        ' 
        ' txtstock
        ' 
        txtstock.Location = New Point(132, 295)
        txtstock.Name = "txtstock"
        txtstock.Size = New Size(121, 23)
        txtstock.TabIndex = 13
        ' 
        ' txtprice
        ' 
        txtprice.Location = New Point(132, 251)
        txtprice.Name = "txtprice"
        txtprice.Size = New Size(121, 23)
        txtprice.TabIndex = 14
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(33, 303)
        Label7.Name = "Label7"
        Label7.Size = New Size(36, 15)
        Label7.TabIndex = 15
        Label7.Text = "Stock"
        ' 
        ' btnsubmit
        ' 
        btnsubmit.BackColor = SystemColors.HotTrack
        btnsubmit.Location = New Point(129, 324)
        btnsubmit.Name = "btnsubmit"
        btnsubmit.Size = New Size(59, 33)
        btnsubmit.TabIndex = 16
        btnsubmit.Text = "Submit"
        btnsubmit.UseVisualStyleBackColor = False
        ' 
        ' btndel
        ' 
        btndel.BackColor = Color.Red
        btndel.ForeColor = SystemColors.ControlLightLight
        btndel.Location = New Point(194, 324)
        btndel.Name = "btndel"
        btndel.Size = New Size(59, 33)
        btndel.TabIndex = 17
        btndel.Text = "Delete"
        btndel.UseVisualStyleBackColor = False
        ' 
        ' txtdetailPost
        ' 
        txtdetailPost.Location = New Point(325, 45)
        txtdetailPost.Multiline = True
        txtdetailPost.Name = "txtdetailPost"
        txtdetailPost.ReadOnly = True
        txtdetailPost.Size = New Size(219, 119)
        txtdetailPost.TabIndex = 18
        ' 
        ' txtdetailVendor
        ' 
        txtdetailVendor.Location = New Point(325, 191)
        txtdetailVendor.Multiline = True
        txtdetailVendor.Name = "txtdetailVendor"
        txtdetailVendor.ReadOnly = True
        txtdetailVendor.Size = New Size(219, 112)
        txtdetailVendor.TabIndex = 19
        ' 
        ' label20
        ' 
        label20.AutoSize = True
        label20.Location = New Point(325, 27)
        label20.Name = "label20"
        label20.Size = New Size(88, 15)
        label20.TabIndex = 20
        label20.Text = "Detail Positions"
        ' 
        ' label30
        ' 
        label30.AutoSize = True
        label30.Location = New Point(325, 173)
        label30.Name = "label30"
        label30.Size = New Size(77, 15)
        label30.TabIndex = 21
        label30.Text = "Detail vendor"
        ' 
        ' itemform1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(604, 386)
        Controls.Add(label30)
        Controls.Add(label20)
        Controls.Add(txtdetailVendor)
        Controls.Add(txtdetailPost)
        Controls.Add(btndel)
        Controls.Add(btnsubmit)
        Controls.Add(Label7)
        Controls.Add(txtprice)
        Controls.Add(txtstock)
        Controls.Add(Combomst)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Combovendor)
        Controls.Add(Combopst)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(label1)
        Controls.Add(txtname)
        Controls.Add(txtcode)
        Name = "itemform1"
        Text = " "
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtcode As TextBox
    Friend WithEvents txtname As TextBox
    Friend WithEvents label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Combopst As ComboBox
    Friend WithEvents Combovendor As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Combomst As ComboBox
    Friend WithEvents txtstock As TextBox
    Friend WithEvents txtprice As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents btnsubmit As Button
    Friend WithEvents btndel As Button
    Friend WithEvents txtdetailPost As TextBox
    Friend WithEvents txtdetailVendor As TextBox
    Friend WithEvents label20 As Label
    Friend WithEvents label30 As Label
End Class
