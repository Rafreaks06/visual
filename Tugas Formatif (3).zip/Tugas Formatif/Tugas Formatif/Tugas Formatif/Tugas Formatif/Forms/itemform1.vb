﻿Imports Npgsql


Public Class itemform1
    Private Sub itemform1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadpos()

    End Sub
    Public Sub loadpos()
        Dim posdao As New PosDao
        Dim rs As NpgsqlDataReader = posdao.getAllcode()
        While rs.Read()
            Combopst.Items.Add(rs.GetString(0))
        End While
        posdao.clearconnection(rs)

        Combopst.SelectedText = "Choose"
    End Sub
    Public Sub populatepos()
        Dim poscode As String = Combopst.SelectedItem.ToString
        Dim posdao As New PosDao()
        Dim rs As NpgsqlDataReader = posdao.getObjectByCode(poscode)
        While rs.Read()
            txtdetailPost.Text = rs.GetString(0) & Environment.NewLine
            txtdetailPost.Text = txtdetailPost.Text & Environment.NewLine & rs.GetString(1)
            txtdetailPost.Text = txtdetailPost.Text & Environment.NewLine
            txtdetailPost.Text = txtdetailPost.Text & "max: " & rs.GetString(2)
            txtdetailPost.Text = txtdetailPost.Text & Environment.NewLine
            txtdetailPost.Text = txtdetailPost.text & "filled: " & rs.GetString(3)
            Exit While
        End While
        posdao.clearconnection(rs)
    End Sub

    Private Sub Combopst_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combopst.SelectedIndexChanged
        populatepos()
    End Sub
End Class