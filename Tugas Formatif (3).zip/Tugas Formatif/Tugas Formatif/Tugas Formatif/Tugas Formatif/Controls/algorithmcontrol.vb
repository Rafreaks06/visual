﻿Public Class algorithmcontrol
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub btnif_Click(sender As Object, e As EventArgs) Handles btnif.Click
        Try
            Dim param1 As Double = CDbl(txtifa.Text)
            Dim param2 As Double = CDbl(txtifb.Text)
            Dim result As String
            If param1 > param2 Then
                result = "Parameter 1 Lebih Besar"
            ElseIf param1 < Param2 Then
                result = "Parameter 1 Lebih Kecil"
            ElseIf param1 = Param2 Then
                result = "Parameter 1 sama dengan Parameter 2"
            Else
                result = "Parameter 1 kena Else"
            End If
            txtifresult.Text = result
        Catch ex As Exception
            If txtifa.Text = txtifb.Text Then
                txtifresult.Text = "Alphabet Sama"
            Else
                txtifresult.Text = "Alphabet Beda"
            End If
        End Try
    End Sub

    Private Sub btnswitch_Click(sender As Object, e As EventArgs) Handles btnswitch.Click
        Try
            Select Case CDbl(txtswitcha.Text)
                Case 10
                    txtswitchresult.Text = "Dapet 10"
                Case 20
                    txtswitchresult.Text = "Dapet 20"
                Case 30
                    txtswitchresult.Text = "Dapet 30"
                Case Else
                    txtswitchresult.Text = "Dapet Else"
            End Select
        Catch ex As Exception
            txtswitchresult.Text = "Bukan Numerik"
        End Try
    End Sub
End Class
