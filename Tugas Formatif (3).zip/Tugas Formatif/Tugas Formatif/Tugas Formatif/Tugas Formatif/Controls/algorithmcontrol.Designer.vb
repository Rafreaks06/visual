﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class algorithmcontrol
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        txtifa = New TextBox()
        txtifb = New TextBox()
        txtifresult = New TextBox()
        txtswitchresult = New TextBox()
        txtfordata = New TextBox()
        txtswitcha = New TextBox()
        txtforcontinue = New TextBox()
        txtforstop = New TextBox()
        txtwhiledata = New TextBox()
        txtwhilecontinue = New TextBox()
        txtwhilesop = New TextBox()
        btnif = New Button()
        btnswitch = New Button()
        btnfor = New Button()
        btnwhile = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(30, 38)
        Label1.Name = "Label1"
        Label1.Size = New Size(43, 15)
        Label1.TabIndex = 0
        Label1.Text = "IF ELSE"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(30, 111)
        Label2.Name = "Label2"
        Label2.Size = New Size(42, 15)
        Label2.TabIndex = 1
        Label2.Text = "Switch"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(31, 181)
        Label3.Name = "Label3"
        Label3.Size = New Size(29, 15)
        Label3.TabIndex = 2
        Label3.Text = "FOR"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(30, 288)
        Label4.Name = "Label4"
        Label4.Size = New Size(42, 15)
        Label4.TabIndex = 3
        Label4.Text = "WHILE"
        ' 
        ' txtifa
        ' 
        txtifa.Location = New Point(88, 34)
        txtifa.Name = "txtifa"
        txtifa.Size = New Size(100, 23)
        txtifa.TabIndex = 4
        ' 
        ' txtifb
        ' 
        txtifb.Location = New Point(194, 34)
        txtifb.Name = "txtifb"
        txtifb.Size = New Size(100, 23)
        txtifb.TabIndex = 5
        ' 
        ' txtifresult
        ' 
        txtifresult.BackColor = SystemColors.ButtonHighlight
        txtifresult.Location = New Point(88, 63)
        txtifresult.Name = "txtifresult"
        txtifresult.ReadOnly = True
        txtifresult.Size = New Size(206, 23)
        txtifresult.TabIndex = 6
        ' 
        ' txtswitchresult
        ' 
        txtswitchresult.Location = New Point(88, 136)
        txtswitchresult.Name = "txtswitchresult"
        txtswitchresult.Size = New Size(206, 23)
        txtswitchresult.TabIndex = 8
        ' 
        ' txtfordata
        ' 
        txtfordata.Location = New Point(88, 178)
        txtfordata.Name = "txtfordata"
        txtfordata.Size = New Size(310, 23)
        txtfordata.TabIndex = 9
        ' 
        ' txtswitcha
        ' 
        txtswitcha.Location = New Point(88, 107)
        txtswitcha.Name = "txtswitcha"
        txtswitcha.Size = New Size(100, 23)
        txtswitcha.TabIndex = 7
        ' 
        ' txtforcontinue
        ' 
        txtforcontinue.Location = New Point(88, 207)
        txtforcontinue.Name = "txtforcontinue"
        txtforcontinue.Size = New Size(100, 23)
        txtforcontinue.TabIndex = 10
        ' 
        ' txtforstop
        ' 
        txtforstop.Location = New Point(88, 236)
        txtforstop.Name = "txtforstop"
        txtforstop.Size = New Size(100, 23)
        txtforstop.TabIndex = 11
        ' 
        ' txtwhiledata
        ' 
        txtwhiledata.Location = New Point(88, 285)
        txtwhiledata.Name = "txtwhiledata"
        txtwhiledata.Size = New Size(310, 23)
        txtwhiledata.TabIndex = 12
        ' 
        ' txtwhilecontinue
        ' 
        txtwhilecontinue.Location = New Point(88, 314)
        txtwhilecontinue.Name = "txtwhilecontinue"
        txtwhilecontinue.Size = New Size(100, 23)
        txtwhilecontinue.TabIndex = 13
        ' 
        ' txtwhilesop
        ' 
        txtwhilesop.Location = New Point(88, 343)
        txtwhilesop.Name = "txtwhilesop"
        txtwhilesop.Size = New Size(100, 23)
        txtwhilesop.TabIndex = 14
        ' 
        ' btnif
        ' 
        btnif.Location = New Point(309, 33)
        btnif.Name = "btnif"
        btnif.Size = New Size(75, 23)
        btnif.TabIndex = 15
        btnif.Text = "Submit"
        btnif.UseVisualStyleBackColor = True
        ' 
        ' btnswitch
        ' 
        btnswitch.Location = New Point(194, 107)
        btnswitch.Name = "btnswitch"
        btnswitch.Size = New Size(75, 23)
        btnswitch.TabIndex = 16
        btnswitch.Text = "Submit"
        btnswitch.UseVisualStyleBackColor = True
        ' 
        ' btnfor
        ' 
        btnfor.Location = New Point(194, 236)
        btnfor.Name = "btnfor"
        btnfor.Size = New Size(75, 23)
        btnfor.TabIndex = 17
        btnfor.Text = "Submit"
        btnfor.UseVisualStyleBackColor = True
        ' 
        ' btnwhile
        ' 
        btnwhile.BackColor = SystemColors.ButtonFace
        btnwhile.Location = New Point(208, 343)
        btnwhile.Name = "btnwhile"
        btnwhile.Size = New Size(75, 23)
        btnwhile.TabIndex = 18
        btnwhile.Text = "Submit"
        btnwhile.UseVisualStyleBackColor = False
        ' 
        ' algorithmcontrol
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        Controls.Add(btnwhile)
        Controls.Add(btnfor)
        Controls.Add(btnswitch)
        Controls.Add(btnif)
        Controls.Add(txtwhilesop)
        Controls.Add(txtwhilecontinue)
        Controls.Add(txtwhiledata)
        Controls.Add(txtforstop)
        Controls.Add(txtforcontinue)
        Controls.Add(txtfordata)
        Controls.Add(txtswitchresult)
        Controls.Add(txtswitcha)
        Controls.Add(txtifresult)
        Controls.Add(txtifb)
        Controls.Add(txtifa)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "algorithmcontrol"
        Size = New Size(563, 428)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtifa As TextBox
    Friend WithEvents txtifb As TextBox
    Friend WithEvents txtifresult As TextBox
    Friend WithEvents txtswitchresult As TextBox
    Friend WithEvents txtfordata As TextBox
    Friend WithEvents txtswitcha As TextBox
    Friend WithEvents txtforcontinue As TextBox
    Friend WithEvents txtforstop As TextBox
    Friend WithEvents txtwhiledata As TextBox
    Friend WithEvents txtwhilecontinue As TextBox
    Friend WithEvents txtwhilesop As TextBox
    Friend WithEvents btnif As Button
    Friend WithEvents btnswitch As Button
    Friend WithEvents btnfor As Button
    Friend WithEvents btnwhile As Button

End Class
