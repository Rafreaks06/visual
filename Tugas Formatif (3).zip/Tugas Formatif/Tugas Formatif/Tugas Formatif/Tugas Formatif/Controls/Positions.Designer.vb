﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Positions
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        DataGridPositions = New DataGridView()
        btnaddPositions = New Button()
        LabelPositions = New Label()
        btnref = New Button()
        CType(DataGridPositions, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' DataGridPositions
        ' 
        DataGridPositions.AllowUserToAddRows = False
        DataGridPositions.AllowUserToDeleteRows = False
        DataGridPositions.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridPositions.Location = New Point(38, 111)
        DataGridPositions.Name = "DataGridPositions"
        DataGridPositions.ReadOnly = True
        DataGridPositions.Size = New Size(705, 289)
        DataGridPositions.TabIndex = 8
        ' 
        ' btnaddPositions
        ' 
        btnaddPositions.Location = New Point(572, 36)
        btnaddPositions.Name = "btnaddPositions"
        btnaddPositions.Size = New Size(153, 42)
        btnaddPositions.TabIndex = 7
        btnaddPositions.Text = "Add New"
        btnaddPositions.UseVisualStyleBackColor = True
        ' 
        ' LabelPositions
        ' 
        LabelPositions.AutoSize = True
        LabelPositions.Location = New Point(38, 50)
        LabelPositions.Margin = New Padding(6, 0, 6, 0)
        LabelPositions.Name = "LabelPositions"
        LabelPositions.Size = New Size(94, 15)
        LabelPositions.TabIndex = 6
        LabelPositions.Text = "Master Positions"
        ' 
        ' btnref
        ' 
        btnref.Location = New Point(384, 36)
        btnref.Name = "btnref"
        btnref.Size = New Size(153, 42)
        btnref.TabIndex = 9
        btnref.Text = "Refresh"
        btnref.UseVisualStyleBackColor = True
        ' 
        ' Positions
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        Controls.Add(btnref)
        Controls.Add(DataGridPositions)
        Controls.Add(btnaddPositions)
        Controls.Add(LabelPositions)
        Name = "Positions"
        Size = New Size(780, 437)
        CType(DataGridPositions, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents DataGridPositions As DataGridView
    Friend WithEvents btnaddPositions As Button
    Friend WithEvents LabelPositions As Label
    Friend WithEvents btnref As Button

End Class
