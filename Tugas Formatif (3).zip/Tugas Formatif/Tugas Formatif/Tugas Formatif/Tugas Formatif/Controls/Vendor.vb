﻿Imports System.Drawing.Text

Public Class Vendor
    Private Sub Vendor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadData()
    End Sub

    Public Sub loadData()
        Try
            Dim VendorDao As New VendorDao() 'mengambi database'
            Dim table As DataTable = VendorDao.loadAlldata() 'memuat semua data'
            DataGridVendor.DataSource = table 'tempel ke design'
            DataGridVendor.Columns("id").Visible = False 'umpetin id'
            DataGridVendor.Columns("isdelete").Visible = False 'umpetin id'

        Catch ex As Exception
            MessageBox.Show("Gagal Mengambil data:" & ex.Message)
        End Try
    End Sub

    Private Sub btnaddvendor_Click(sender As Object, e As EventArgs) Handles btnaddVendor.Click
        VendorForm.Show()
    End Sub

    Private Sub DataGridVendor_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridVendor.CellContentClick

    End Sub

    Private Sub DataGridVendor_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridVendor.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DataGridVendor.Rows(e.RowIndex)
            Dim vendorform As New VendorForm()
            vendorform.txtaddres.Text = row.Cells("address").Value.ToString()
            vendorform.txtcode.Text = row.Cells("code").Value.ToString()
            vendorform.txtemail.Text = row.Cells("email").Value.ToString()
            vendorform.txtid.Text = row.Cells("id").Value.ToString()
            vendorform.txtname.Text = row.Cells("Name").Value.ToString()
            vendorform.txtphone.Text = row.Cells("Phone").Value.ToString()
            vendorform.txtperson.Text = row.Cells("pic_name").Value.ToString()
            vendorform.Show()


        End If
    End Sub

    Private Sub btnref_Click(sender As Object, e As EventArgs) Handles btnref.Click
        loadData()
    End Sub
End Class
